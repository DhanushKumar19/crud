import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
//import { MatInputModule } from '@angular/material/input';

import { AppComponent } from './app.component';
import { AppFormComponent } from './form/form.component';
import { DisplayItemsComponent } from './display-items/display-items.component';
import { HeaderComponent } from './header/header.component.js';

@NgModule({
  declarations: [
    AppComponent,
    DisplayItemsComponent,
    AppFormComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    //MatInputModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
