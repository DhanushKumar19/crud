import { Component ,EventEmitter, Output} from "@angular/core";
import { Post } from '../model';
import { NgForm } from '@angular/forms';
import { PostService } from '../header/form.service';


@Component({
  selector : 'app-form',
  templateUrl : './form.component.html',
  styleUrls : ['./form.component.css']
})
export class AppFormComponent {
fName : String='';
// lName : String='';
// employeeId : number = null;
// email='';
// gender='';
@Output() postCreated = new EventEmitter<Post>();
constructor(public postService: PostService){}

onSubmit(form: NgForm){
  if(form.invalid){
    return;
  }
    const post : Post = {
    fName : form.value.fName//,
    // lName : this.lName,
    // employeeId : this.employeeId,
    // email : this.email,
    // gender : this.gender
  };
  //console.log(post);
 this.postCreated.emit(post);
 //this.postService.addPosts(form.value.fName);
}


}
