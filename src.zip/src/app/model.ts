export interface Post{
  fName : String;
}
