import { Component, OnInit ,Input} from '@angular/core';
import { Post } from '../model';
import { PostService } from '../header/form.service';

@Component({
  selector: 'app-display-items',
  templateUrl: './display-items.component.html',
  styleUrls: ['./display-items.component.css']
})
export class DisplayItemsComponent implements OnInit {

   @Input() posts : Post[]=[];
  // postService:PostService;
  // constructor(postService : PostService) {
  //   this.postService = postService;
  //  }
  //  constructor(public postService : PostService) {
  //  }
  ngOnInit(): void {
   // this.posts = this.postService.getPosts();
  }


}
